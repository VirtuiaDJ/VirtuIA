from flask import Flask, render_template, request, jsonify, g
import os, json, sqlite3, requests
from datetime import datetime
from deepseek_integration import consulta_deepseek
from apscheduler.schedulers.background import BackgroundScheduler

app = Flask(__name__)
DATABASE = 'virtuai.db'
app.secret_key = 'sua-chave-secreta'

# Banco de dados
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        with open("schema.sql", "r", encoding="utf-8") as f:
            db.executescript(f.read())
        db.commit()

# Funções para manipular dados das IAs
def carregar_ia(nome_ia):
    caminho = os.path.join("data", f"{nome_ia}.json")
    if os.path.exists(caminho):
        with open(caminho, "r", encoding="utf-8") as arquivo:
            return json.load(arquivo)
    return {"nome": nome_ia, "respostas": {}, "memoria": [], "advanced": {}}

def salvar_ia(nome_ia, dados):
    caminho = os.path.join("data", f"{nome_ia}.json")
    with open(caminho, "w", encoding="utf-8") as arquivo:
        json.dump(dados, arquivo, indent=4, ensure_ascii=False)

def responder_ia(mensagem, ia_nome):
    if "detalhar" in mensagem.lower():
        resposta_deep = consulta_deepseek(mensagem)
        if resposta_deep:
            return f"{ia_nome.capitalize()} (DeepSeek): {resposta_deep}"
    ia = carregar_ia(ia_nome)
    msg = mensagem.lower().strip()
    for chave, resp in ia.get("respostas", {}).items():
        if chave in msg:
            return f"{ia_nome.capitalize()}: {resp}"
    if ia.get("advanced", {}).get("apresentacao"):
        return f"{ia_nome.capitalize()} (Avançado): {ia['advanced']['apresentacao']}"
    return f"{ia_nome.capitalize()}: Ainda estou aprendendo a responder isso."

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/enviar", methods=["POST"])
def enviar():
    dados = request.get_json()
    ia = dados.get("ia")
    mensagem = dados.get("mensagem")
    resposta = responder_ia(mensagem, ia)
    
    db = get_db()
    db.execute("INSERT INTO chat_logs (ia, mensagem, resposta, timestamp) VALUES (?, ?, ?, ?)",
               (ia, mensagem, resposta, datetime.now().isoformat()))
    db.commit()
    
    ia_data = carregar_ia(ia)
    ia_data["memoria"].append({"pergunta": mensagem, "resposta": resposta})
    salvar_ia(ia, ia_data)
    
    return jsonify({"resposta": resposta})

@app.route("/treinar", methods=["POST"])
def treinar():
    dados = request.get_json()
    ia = dados.get("ia")
    pergunta = dados.get("pergunta").lower().strip()
    resposta = dados.get("resposta")
    ia_data = carregar_ia(ia)
    ia_data.setdefault("respostas", {})
    ia_data["respostas"][pergunta] = resposta
    salvar_ia(ia, ia_data)
    return jsonify({"resultado": f"{ia.capitalize()} treinada com sucesso!"})

@app.route("/treinar_deepseek", methods=["POST"])
def treinar_deepseek():
    dados = request.get_json()
    ia = dados.get("ia")
    mensagem = dados.get("mensagem")
    resposta_deep = consulta_deepseek(mensagem)
    ia_data = carregar_ia(ia)
    ia_data.setdefault("respostas", {})
    ia_data["respostas"][mensagem.lower()] = resposta_deep
    salvar_ia(ia, ia_data)
    return jsonify({"resultado": f"{ia.capitalize()} treinada via DeepSeek."})

@app.route("/configuracoes", methods=["POST"])
def configuracoes():
    dados = request.get_json()
    config_path = os.path.join("config", "autonomia.json")
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(dados, f, indent=4, ensure_ascii=False)
    return jsonify({"resultado": "Configurações atualizadas com sucesso!"})

@app.route("/api/monitoramento")
def monitoramento():
    db = get_db()
    cursor = db.execute("SELECT COUNT(*) FROM chat_logs")
    total_msgs = cursor.fetchone()[0]
    dados = {
        "total_mensagens": total_msgs,
        "ultima_atualizacao": datetime.now().isoformat(),
        "niveis": {
            "z4quel": 5,
            "l3ticia": 5,
            "symbio": 6
        }
    }
    return jsonify(dados)

# Agendamento de Treinamento Contínuo e Simulação de Reuniões entre IAs
def treinamento_continuo():
    for ia in ["z4quel", "l3ticia", "symbio"]:
        print(f"[Treinamento Contínuo] Executado para {ia} em {datetime.now().isoformat()}")
        # Aqui, ações extras podem ser executadas: geração de relatórios, feedback, etc.

from apscheduler.schedulers.background import BackgroundScheduler
scheduler = BackgroundScheduler()
scheduler.add_job(func=treinamento_continuo, trigger="interval", minutes=5)
scheduler.start()

# NGROK Integration (Opção Automática ou Manual)
# Para ativar o túnel NGROK automaticamente, descomente o bloco abaixo:
# import subprocess
# subprocess.Popen("ngrok http 5000", shell=True)
# print("NGROK iniciado, verifique a URL pública no terminal.")

if __name__ == "__main__":
    if not os.path.exists(DATABASE):
        init_db()
    app.run(debug=True)